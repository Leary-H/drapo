#include <xc.h>
#include <p33Fxxxx.h>
//do not change the order of the following 2 definitions
#define FCY 12800000UL 
#include <libpic30.h>

#include "lcd.h"
#include "led.h"

/* Configuration of the Chip */
// Initial Oscillator Source Selection = Primary (XT, HS, EC) Oscillator with PLL
#pragma config FNOSC = PRIPLL
// Primary Oscillator Mode Select = XT Crystal Oscillator mode
#pragma config POSCMD = XT
// Watchdog Timer Enable = Watchdog Timer enabled/disabled by user software
// (LPRC can be disabled by clearing the SWDTEN bit in the RCON register)
#pragma config FWDTEN = OFF

int main(){
    //Init LCD and LEDs
    lcd_initialize();
    led_init();
	
    // Clear the Screen and reset the cursor
    lcd_clear();
    lcd_locate(0, 0);
    
    // Print Hello World
    lcd_printf("Hello World!\r");
    lcd_printf("Linxiao Han\rZiang Dou\r");
    
     unsigned int counter = 0;
     
    
    while(counter < 31)
    {
        lcd_locate(0,3);
        lcd_clear_row(3)
        counter++; 
        TOGGLELED(LED5_PORT);
        if(LED5_PORT == 0)
            TOGGLELED(LED4_PORT);
        if(LED5_PORT == 0 && LED4_PORT == 0)
            TOGGLELED(LED3_PORT);
        if(LED5_PORT == 0 && LED4_PORT == 0 && LED3_PORT == 0)
            TOGGLELED(LED2_PORT);
        if(LED5_PORT == 0 && LED4_PORT == 0 && LED3_PORT == 0 && LED2_PORT == 0)
            TOGGLELED(LED1_PORT);
       
        lcd_printf("%d", counter);
        __delay_ms(1000);
        
    }
  
    // Stop
    while(1)
        ;
}

